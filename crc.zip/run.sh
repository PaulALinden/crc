#!/bin/bash

# Compile the C program
gcc main.c -o main
# Run the program
./main

